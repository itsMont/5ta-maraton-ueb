#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int N;

    cin>>N;
    while(N--)
    {
        int Ax, Ay, Bx, By, Cx, Cy, Dx, Dy;

        cin>> Ax>> Ay>> Bx>> By>>Cx>> Cy;

        // calcular determinante
        Dx = Cx - abs(Bx- Ax);
        Dy = Cy - abs(Ay-By);

        // Area es det
        double area = abs((Bx-Ax) * (Cy-By) - (Cx-Bx)*(By-Ay));
        cout<<"Case "<<N+1<<": "<<Dx<<" "<<Dy<<" "<<area<<"\n";
    }
    return 0;
}

// 3
// 0 0 10 0 10 10
// 0 0 10 0 10 -20
// -12 -10 21 21 1 40
